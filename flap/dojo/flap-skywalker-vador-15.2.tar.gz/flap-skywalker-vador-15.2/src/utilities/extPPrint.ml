(** This module extends the PPrint library. *)

open PPrint

let ( ++ ) x y = x ^^ break 1 ^^ y


